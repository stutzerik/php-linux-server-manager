<?php

//EN: Database connection details

$dbhostname = 'localhost'; //IP address or hostname of SQL server 
$dbusername = 'root'; //SQL server username
$dbpassword = ''; //User password
$dbname = 'nextcaligo'; //Database name

?>